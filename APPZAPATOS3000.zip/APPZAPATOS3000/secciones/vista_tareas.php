<?php include('../templates/cabecera.php'); ?>
<?php include('../secciones/tareas.php'); ?>


<div class="row">
    <div class="col-12">
        <br/>
        <div class="row">
        <div class="col-5">
        <form action="" method="post">
        <div class="card">
            <div class="card-header"> Crear Tareas </div>
            <div class="card-body">
            <div class="mb-3 d-none">
                <label for="" class="form-label">ID</label>
                <input type="text"
                        class="form-control" 
                        name="id" 
                        id="id" 
                        value="<?php echo $id; ?>"
                        aria-describedby="helpId" placeholder="ID">
            </div>
            <div class="mb-3">
                <label for="nombre_tarea" class="form-label">Descripcion</label>
                <input type="text"
                        class="form-control" 
                        name="nombre_tarea" 
                        id="nombre_tarea" 
                        value="<?php echo $nombre_tarea; ?>"
                        aria-describedby="helpId" 
                        placeholder="Agregar Tarea">
            </div>

            <div class="btn-group" role="group" aria-label="">
                <button type="submit" name="accion" value="agregar" class="btn btn-primary">Agregar</button>
                <button type="submit" name="accion" value="editar" class="btn btn-primary">Editar</button>
                <button type="submit" name="accion" value="borrar" class="btn btn-primary">Borrar</button>
            </div>  

        </div>
    
</div>


</form>



</div>

<div class="col-7">

    <table class="table">
        <thead>
            <tr>
                <th>ID Tarea</th>
                <th>Detalle</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            
        <?php foreach($listaTareas as $tarea){ ?>
            <tr>
                <td> <?php echo $tarea['id']; ?> </td>
                <td> <?php echo $tarea['nombre_tarea']; ?> </td>
                <td> 
                <form action="" method="post">
                    <input type="hidden" name="id" id="id" value="<?php echo $tarea['id']; ?>" />
                    <input type="submit" value="Seleccionar" name="accion" class="btn btn-info"/>
                </form>    
            
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    


</div>
</div>
</div>

<?php include('../templates/pie.php'); ?>