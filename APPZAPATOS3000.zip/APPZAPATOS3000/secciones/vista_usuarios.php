<?php include('../templates/cabecera.php'); ?>
<?php include('../secciones/usuarios.php'); ?>
<br/>
<div class="row">
    <div class="col-5">
        <form action="" method="post">
        <div class="card">
            <div class="card-header">
            Ingresar Usuarios
            </div>
            <div class="card-body">
            
            <div class="mb-3 d-none">
              <label for="id" class="form-label">ID</label>
              <input type="text"
                class="form-control" name="id" value="<?php echo $id;?>" id="id" aria-describedby="helpId" placeholder="ID">
            </div>
            <div class="mb-3">
              <label for="nombre" class="form-label">Nombre</label>
              <input type="text"
                class="form-control" name="nombre"  value="<?php echo $nombre;?>" id="nombre" aria-describedby="helpId" placeholder="Escriba el nombre">
            </div>

            <div class="mb-3">
              <label for="apellidos" class="form-label">Apellidos</label>
              <input type="text"
                class="form-control" name="apellidos"  value="<?php echo $apellidos;?>" id="apellidos" aria-describedby="helpId" placeholder="Escriba los apellidos">
              
            </div>
            
            <div class="mb-3">
              <label for="" class="form-label">Tipo de Tarea:</label>

              <select multiple class="form-control" name="tareas[]" id="listaTareas">
                
              <?php foreach($tareas as $tarea){ ?>
                    <option
                    <?php 
                        if(!empty($arregloTareas)):
                            if(in_array($tarea['id'],$arregloTareas)):
                                echo 'selected';
                            endif;
                        endif;
                    ?> 
                    value="<?php echo $tarea['id'];?>" >
                    <?php echo $tarea['id'];?> - <?php echo $tarea['nombre_tarea'];?>
                    </option>

              <?php  } ?>

              </select>

            </div>

            <div class="btn-group" role="group" aria-label="">
                <button type="submit" name="accion" value="agregar" class="btn btn-primary">Agregar</button>
                <button type="submit" name="accion" value="editar"class="btn btn-primary">Editar</button>
                <button type="submit" name="accion" value="borrar" class="btn btn-primary">Borrar</button>
            </div>


            </div>
            
        </div>


        </form>
    </div>
    <div class="col-7">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                  
                <?php foreach($usuarios as $usuario): ?>
                    <tr>
                        <td><?php echo $usuario['id'];?></td>

                        <td> 
                            <?php echo $usuario['nombre'];?> <?php echo $usuario['apellidos'];?> 
                            <br/>
                            <?php foreach($usuario["tareas"] as $tarea){ ?>
                                    - <a href="certificado.php?idtarea=<?php echo $tarea['id']; ?>&idusuario=<?php echo $usuario["id"];?>"> 
                                    <i class="bi bi-filetype-pdf text-danger"></i> <?php echo $tarea['nombre_tarea']; ?> 
                                </a><br/>
                                

                            <?php  } ?>
                        
                        </td>


                        <td>
                        <form action="" method="post">

                            <input type="hidden" name="id" value="<?php echo $usuario['id'];?>">
                            <input type="submit" value="Seleccionar" name="accion" class="btn btn-info">
                        </form>


                        </td>
                    </tr>
                  <?php endforeach; ?>

                </tbody>
            </table>
            
    </div>
</div>


<link href="https://cdn.jsdelivr.net/npm/tom-select@2.0.2/dist/css/tom-select.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.0.2/dist/js/tom-select.complete.min.js"></script>

<script>
    new TomSelect('#listaTareas');
</script>


<?php include('../templates/pie.php'); ?>