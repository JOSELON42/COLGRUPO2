<?php 

include_once '../configuraciones/bd.php';
$conexionBD=BD::crearInstancia();

$id=isset($_POST['id'])?$_POST['id']:'';
$nombre=isset($_POST['nombre'])?$_POST['nombre']:'';
$apellidos=isset($_POST['apellidos'])?$_POST['apellidos']:'';

$tareas=isset($_POST['tareas'])?$_POST['tareas']:'';
$accion=isset($_POST['accion'])?$_POST['accion']:'';



if($accion!=""){
    switch($accion){
        case 'agregar':

            $sql="INSERT INTO usuarios (id, nombre, apellidos) VALUES (NULL,:nombre,:apellidos)";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':nombre',$nombre);
            $consulta->bindParam(':apellidos',$apellidos);
            $consulta->execute();
            
            $idUsuario=$conexionBD->lastInsertId();

            foreach($tareas as $tarea){
                $sql="INSERT INTO usuarios_tareas (id, idusuario, idtarea) VALUES (NULL,:idusuario,:idtarea)";
                $consulta=$conexionBD->prepare($sql);
                $consulta->bindParam(':idusuario',$idUsuario);
                $consulta->bindParam(':idtarea',$idtarea);
                $consulta->execute();
            }

        break;

        case 'Seleccionar':
            
           
            $sql="SELECT * FROM usuarios WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':id',$id);
            $consulta->execute();
            $usuario=$consulta->fetch(PDO::FETCH_ASSOC);
            
            $nombre=$usuario['nombre'];
            $apellidos=$usuario['apellidos'];
            
            $sql="SELECT usuarios.id FROM usuarios_tareas 
            INNER JOIN usuarios ON usuarios.id=usuarios_tareas.idtarea 
            WHERE usuarios_tareas.idusuario=:idusuario";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':idusuario',$id);
            $consulta->execute();
            $tareasUsuario=$consulta->fetchAll(PDO::FETCH_ASSOC);

         

            foreach($tareasUsuario as $tarea){
                $arregloTareas[]=$tarea['id'];
            }
        break;

        case "borrar":
            $sql="DELETE FROM usuarios WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':id',$id);
            $consulta->execute();
        break;

        case "editar":
            $sql="UPDATE usuarios SET nombre=:nombre, apellidos=:apellidos
             WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':nombre',$nombre);
            $consulta->bindParam(':apellidos',$apellidos);
            $consulta->bindParam(':id',$id);
            $consulta->execute();

            if(isset($tareas)){

                $sql="DELETE FROM usuarios_tareas WHERE idusuario=:idusuario";
                $consulta=$conexionBD->prepare($sql);
                $consulta->bindParam(':idusuario',$id);
                $consulta->execute();

                foreach($tareas as $tarea){

                    $sql="INSERT INTO usuarios_tareas (id, idusuario, idtarea) 
                    VALUES (NULL,:idusuario,:idtarea)";
                    $consulta=$conexionBD->prepare($sql);
                    $consulta->bindParam(':idusuario',$id);
                    $consulta->bindParam(':idtarea',$tarea);
                    $consulta->execute();
                }
                $arregloTareas=$tarea;


            }


    }  

}



$sql="SELECT * FROM usuarios";
$listaUsuarios=$conexionBD->query($sql);
$usuarios=$listaUsuarios->fetchAll();

foreach($usuarios as $clave => $usuario){

    $sql="SELECT * FROM tareas 
    WHERE id IN (SELECT idtarea FROM usuarios_tareas WHERE idusuario=:idusuario)";

    $consulta=$conexionBD->prepare($sql);
    $consulta->bindParam(':idusuario',$usuario['id']);
    $consulta->execute();
    $tareasUsuario=$consulta->fetchAll();
    $usuarios[$clave]['tareas']=$tareasUsuario;
}

$sql="SELECT * FROM tareas";
$listaTareas=$conexionBD->query($sql);
$tareas=$listaTareas->fetchAll();


?>