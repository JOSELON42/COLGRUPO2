<?php 
require('../librerias/fpdf/fpdf.php');
include_once '../configuraciones/bd.php';
$conexionBD=BD::crearInstancia();
function agregarTexto($pdf,$texto,$x,$y,$align='L',$fuente,$size=10,$r=0,$g=0,$b=0){
    $pdf->SetFont($fuente,"",$size);
    $pdf->SetXY($x,$y);
    $pdf->SetTextColor($r,$g,$b);
    $pdf->Cell(0,10,$texto,0,0,$align);
}
function agregarImagen($pdf,$imagen,$x,$y){
    $pdf->Image($imagen,$x,$y,0);
}

$idtarea=isset($_GET['idtarea'])?$_GET['idtarea']:'';
$idusuario=isset($_GET['idusuario'])?$_GET['idusuario']:'';

$sql="SELECT usuarios.nombre, usuarios.apellidos,tareas.nombre_tarea 
FROM usuarios, tareas WHERE usuarios.id=:idusuario AND tareas.id=:idtarea";
$consulta=$conexionBD->prepare($sql);
$consulta->bindParam(':idusuario',$idusuario);
$consulta->bindParam(':idtarea',$idtarea);
$consulta->execute();
$usuario=$consulta->fetch(PDO::FETCH_ASSOC);


$pdf=new FPDF("L","mm",array(254,194));
$pdf->AddPage();
$pdf->setFont("Arial","B",16);
agregarImagen($pdf,"../src/certificado_.jpg",0,0);
agregarTexto($pdf,ucwords(utf8_decode($usuario['nombre']." ".$usuario['apellidos'])),60,70,'L',"Helvetica",30,0,84,115);
agregarTexto($pdf,$usuario['nombre_tarea'],-250,115,'C',"Helvetica",20,0,84,115);
agregarTexto($pdf,date("d/m/Y"),-355,160,'C',"Helvetica",11,0,84,115);
$pdf->Output();



?>