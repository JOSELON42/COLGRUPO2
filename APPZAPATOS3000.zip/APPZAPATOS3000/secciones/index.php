<?php include('../templates/cabecera.php'); ?>

   <div class="p-5 bg-light">
       <div class="container">
           <h1 class="display-3">Bienvenido a ZAPATOS3000</h1>
           <p class="lead">Generador de Tareas</p>
           <hr class="my-2">
           <p>Iniciar la aplicación</p>
           <p class="lead">
               <a class="btn btn-primary btn-lg" href="vista_usuarios.php" role="button">Vamos</a>
           </p>
       </div>
   </div>

<?php include('../templates/pie.php'); ?>