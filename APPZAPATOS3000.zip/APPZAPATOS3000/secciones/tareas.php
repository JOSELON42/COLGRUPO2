<?php 
include_once '../configuraciones/bd.php';
$conexionBD=BD::crearInstancia();

$id=isset($_POST['id'])?$_POST['id']:'';
$nombre_tarea=isset($_POST['nombre_tarea'])?$_POST['nombre_tarea']:'';
$accion=isset($_POST['accion'])?$_POST['accion']:'';

if($accion!=''){
    
    switch($accion){

        case 'agregar':
            
            $sql="INSERT INTO tareas (id, nombre_tarea) VALUES (NULL,:nombre_tarea)";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':nombre_tarea',$nombre_tarea);
            $consulta->execute();

        break;
        case 'editar':
            $sql="UPDATE tareas SET nombre_tarea=:nombre_tarea WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':id',$id);
            $consulta->bindParam(':nombre_tarea',$nombre_tarea);
            $consulta->execute();

           
        break;
        case 'borrar':
            $sql="DELETE FROM tareas WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':id',$id);
            $consulta->execute();

        break;

        case "Seleccionar":
            $sql="SELECT * FROM tareas WHERE id=:id";
            $consulta=$conexionBD->prepare($sql);
            $consulta->bindParam(':id',$id);
            $consulta->execute();
            $tarea=$consulta->fetch(PDO::FETCH_ASSOC);
            $nombre_tarea=$tarea['nombre_tarea'];
            

        break;

    }

}
    
$consulta=$conexionBD->prepare("SELECT * FROM tareas");
$consulta->execute();
$listaTareas=$consulta->fetchAll();



?>